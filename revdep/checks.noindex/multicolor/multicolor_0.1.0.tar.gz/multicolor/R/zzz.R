
.onAttach <- function(...) {
  use_color()
}
