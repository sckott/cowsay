library(testthat)
library(multicolor)

test_check("multicolor")
