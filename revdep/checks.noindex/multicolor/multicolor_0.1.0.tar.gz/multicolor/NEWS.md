# multicolor 0.1.0

* First version of multicolor! 

