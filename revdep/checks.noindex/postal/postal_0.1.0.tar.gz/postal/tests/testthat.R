library(testthat)
library(postal)

test_check("postal")
