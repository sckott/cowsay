
# postal 0.1.0

This is the first version of the postal package.
